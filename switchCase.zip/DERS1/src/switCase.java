import java.util.Scanner;

public class switCase {

    public static void main(String[] args) {
        int n1,n2,select;
        Scanner input= new Scanner(System.in);
        System.out.println("ilk sayıyı girin:");
        n1= input.nextInt();

        System.out.println("ikinci sayıyı giriniz:");
        n2=input.nextInt();

        System.out.println("1-Topla\n2-çıkar\n3-çarpma\n4-Bölme: ");

        System.out.println("lütfen bir seçim yapınız:");

        select=input.nextInt();

        switch (select){

            case 1:
                System.out.println(n1+n2);
            break;

            case 2:
                System.out.println(n1-n2);
            break;

            case 3:
                System.out.println(n1*n2);
            break;
            case  4:
                System.out.println(n1/n2);
                break;

            default:
                System.out.println("sayı sıfıra bölünmez:");

                break;

        }

    }
}
